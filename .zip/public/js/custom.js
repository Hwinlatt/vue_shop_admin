//Active function
let activeSidebar = (c) => {
    $('.dashboard_view').removeClass('active');
    $(c).addClass('active');
}
