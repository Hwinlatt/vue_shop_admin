<?php $__env->startSection('contact'); ?>
    <div class="container mt-1">
        <div class="row">
            <div class="col-md-12 mt-4">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Contact Table</h6>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Subject</th>
                                    <th scope="col">Message</th>
                                    <th scope="col">Created_at</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($loop->index+1); ?></th>
                                    <th scope="row"><?php echo e($contact->name); ?></th>
                                    <td><?php echo e($contact->email); ?></td>
                                    <td><?php echo e($contact->subject); ?></td>
                                    <td><?php echo e($contact->message); ?></td>
                                    <td><?php echo e($contact->created_at->format('d-M-Y')); ?></td>
                                    <td>
                                        <div class="d-flex">
                                            
                                            <a href="<?php echo e(route('member#contact_delete',$contact->id)); ?>" class="btn btn-danger mx-1 ">Delete</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class=" float-end">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            activeSidebar('.contact_view');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\a to z\projects\shop_vue+laravel\api\resources\views/page/contact/index.blade.php ENDPATH**/ ?>