<?php $__env->startSection('contact'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-2">
                <div class="float-start">
                    <a href="<?php echo e(route('member#product')); ?>" class="btn btn-link"><i class="fa-sharp fa-solid fa-arrow-left-long"></i> Back</a>
                </div>
            </div>
            <div class="col-md-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Product Edit Form</h6>
                    <div class="row">
                        <div class="col-md-4 offset-8 float-end">
                            <img src="<?php echo e(asset('images/'.$product->image)); ?>" style="width: 200px;height:200px" alt="">
                        </div>
                    </div>
                    <form action="<?php echo e(route('member#product_update',$product->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="p-name" class="form-label">Name</label>
                            <input required type="text" name="name" autocomplete="none" value="<?php echo e(old('name',$product->name)); ?>"
                                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="p-name">
                            <div class="invalid-feedback">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="p-category" class="form-label">Categroy</label>
                                    <select required name="categoryId" id="p-category"
                                        class="form-select  <?php $__errorArgs = ['categoryId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Choose Category..</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(old('categoryId',$product->category_id) == $c->id): ?> selected <?php endif; ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <div class="invalid-feedback">
                                        <?php $__errorArgs = ['categoryId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label for="p-qty" class="form-label">Qty</label>
                                    <input required type="number" name="qty" value="<?php echo e(old('qty',$product->qty)); ?>"
                                        class="form-control <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="none"
                                        id="p-qty">
                                    <div class="invalid-feedback">
                                        <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row  my-2">
                            <label for="" class="form-label">Information</label>
                            <div id="infoContainer" class="information m-0 p-0">
                                <div class="row m-0 p-0 sub-information">
                                    <div class="col-md-5">
                                        <input readonly type="text" required placeholder="Enter Key" value="Price"
                                            class="key form-control  <?php $__errorArgs = ['information'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" required value=""  placeholder="Enter Value"
                                            class="value form-control <?php $__errorArgs = ['information'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    </div>
                                </div>
                                <div class="row m-0 p-0 sub-information my-1">
                                    <div class="col-md-5">
                                        <input readonly type="text" placeholder="Enter Key"
                                            class="key form-control <?php $__errorArgs = ['information'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" placeholder="Enter Value"
                                            class="value form-control <?php $__errorArgs = ['information'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    </div>
                                </div>
                            </div>
                            <div>
                                <button class="float-end btn btn-link" type="button" id="addInfonBtn">Add
                                    Information</button>
                            </div>
                        </div>
                        <div class="mb-3 d-none">
                            <label for="p-info" class="form-label">Info Data</label>
                            <textarea name="information" required class="form-control" id="p-info" rows="1"><?php echo e(old('information',$product->information)); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="p-image" class="form-label">Updae Image</label>
                            <input type="file"  name="image" class="form-control" id="p-image">
                        </div>
                        <div class="mb-3">
                            <label for="p-desc" class="form-label">Description</label>
                            <textarea name="description" required class="form-control" id="p-desc" rows="6"><?php echo e(old('description',$product->description)); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('js/product/main.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            activeSidebar('.product_view');
            oldInformationGet();
            informationGet();
            informationKeep();
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\a to z\projects\shop_vue+laravel\api\resources\views/page/product/edit.blade.php ENDPATH**/ ?>