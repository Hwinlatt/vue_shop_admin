
<div>
    Cannot Register Here please go to <a href="">User Register</a>
</div>
<?php /**PATH D:\a to z\projects\shop_vue+laravel\api\resources\views/auth/register.blade.php ENDPATH**/ ?>