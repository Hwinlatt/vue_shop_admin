<?php $__env->startSection('contact'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-2">
                <div class="float-end">
                    <button class="btn btn-link" data-bs-toggle="modal" data-bs-target="#addSlideShow">Add <i
                            class="fa-solid fa-plus"></i></button>
                </div>
            </div>
            <div class="col-md-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4"><i class="fa-solid fa-layer-group"></i> SlideShows</h6>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Goto</th>
                                    <th scope="col">TimeStamp</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="col-1">
                                            <select old_num="<?php echo e($slide->custom_number); ?>"
                                                class="form-select slideOrderSelect">
                                                <?php for($i = 0; $i < count($slides); $i++): ?>
                                                    <option <?php if($i + 1 == $slide->custom_number): echo 'selected'; endif; ?>><?php echo e($i + 1); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </td>
                                        <td><img src="<?php echo e(asset('images/' . $slide->image)); ?>" height="200" width="300"
                                                alt=""></td>
                                        <td><p style="height: 200px;overflow:auto"><?php echo e($slide->description); ?></p></td>
                                        <td>
                                            <?php if($slide->link != null): ?>
                                                <a class="btn btn-link" href="<?php echo e($slide->link); ?>">Link</a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span>C - <?php echo e($slide->created_at->format('M/d/Y')); ?></span><br>
                                            <span>U - <?php echo e($slide->updated_at->format('M/d/Y')); ?></span><br>
                                        </td>
                                        <td>
                                            <div>
                                                <button class="btn btn-danger btn-sm" onclick="deleteSlide(<?php echo e($slide->id); ?>)">
                                                    <i class="fa-solid fa-trash"></i></button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class=" float-end">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal -->
    <div class="modal fade" id="addSlideShow" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Insert <i
                            class="fa-solid fa-layer-group"></i>SlideShow</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('member#slideShow_insert')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group mb-2">
                            <label for="inputTitle">Title</label>
                            <input required type="text" id="inputTitle" placeholder="Enter Title" name="title"
                                value="<?php echo e(old('title')); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-2">
                            <label for="inputImage">Image</label>
                            <input required type="file" id="inputImage" placeholder="Enter Image" accept="image/*"
                                class="form-control" name="image">
                        </div>
                        <div class="form-group mb-2">
                            <label for="inputLink">Link</label>
                            <input type="text" class="form-control" placeholder="Enter link to go" id="inputLink"
                                value="<?php echo e(old('link')); ?>" name="link">
                        </div>
                        <div class="form-group mb-2">
                            <label for="inputDesc">Description</label>
                            <textarea name="description" class="form-control" id="inputDesc" placeholder="Enter Description" rows="5"><?php echo e(old('description')); ?></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

    <?php if(session('success')): ?>
        <script>
            Swal.fire('Success', '<?php echo e(session('success')); ?>', 'success');
        </script>
    <?php endif; ?>
    <script>
        $(document).ready(function() {
            activeSidebar('.slideShow_view')
            $('.slideOrderSelect').change(function(e) {
                let new_num = $(this).val();
                let old_num = $(this).attr('old_num');
                $('.slideOrderSelect').attr('disabled', 'true');
                let url = 'slide_show/num_change/' + old_num + '/' + new_num;
                window.location.href = url;
            });
        });

        function deleteSlide(id) {
            Swal.fire({
                title: 'Are you sure to Delete?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    let url = 'slide_show/delete/' + id;
                    window.location.href = url;
                    // Swal.fire(
                    //     'Deleted!',
                    //     'Your file has been deleted.',
                    //     'success'
                    // )
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\a to z\projects\shop_vue+laravel\api\resources\views/page/slideshow/list.blade.php ENDPATH**/ ?>