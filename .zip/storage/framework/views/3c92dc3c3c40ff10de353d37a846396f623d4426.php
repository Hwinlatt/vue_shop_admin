<?php echo e($slot); ?>

<?php /**PATH D:\a to z\projects\shop_vue+laravel\api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>