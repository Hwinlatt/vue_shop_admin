
<?php $__env->startSection('contact'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-2">
                <div class="float-end">
                    <button class="btn btn-link" data-bs-toggle="modal" data-bs-target="#filterModel">Filter <i class="fa-solid fa-filter"></i></button>
                </div>
            </div>
            <div class="col-md-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Orders Table</h6>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Order Id</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">City</th>
                                    <th scope="col">Payment</th>
                                    <th scope="col">Order Date</th>
                                    <th scope="col">Total Price</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($order->order_id); ?></th>
                                        <td><span class=" text-uppercase"><?php echo e($order->status); ?></span></td>
                                        <td><?php echo e($order->city); ?></td>
                                        <td><?php echo e($order->payment); ?></td>
                                        <td><?php echo e($order->created_at->format('d-M-Y')); ?></td>
                                        <td>
                                            <?php
                                                $total = 0;
                                                foreach ($order->order_items as $item) {
                                                    $total += $item->price;
                                                }
                                                echo $total + $order->delivery_charges;
                                            ?>
                                        </td>
                                        <td>
                                            <div class="d-flex">
                                                <a href="<?php echo e(route('member#order_info',$order->order_id)); ?>" class="btn btn-primary editCategoryBtn">More</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class=" float-end">
                            <?php echo e($orders->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="filterModel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form action="<?php echo e(route('member#order')); ?>" method="GET">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Order Filters</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row align-content-center mb-2">
                            <div class="col-4">Status</div>
                            <div class="col">
                                <select class="form-select" name="status">
                                    <option <?php if(request('status')==''): ?> selected <?php endif; ?> value="">All</option>
                                    <option <?php if(request('status')=='pending'): ?> selected <?php endif; ?> value="pending">Pending</option>
                                    <option <?php if(request('status')=='accept'): ?> selected <?php endif; ?> value="accept">Accept</option>
                                    <option <?php if(request('status')=='success'): ?> selected <?php endif; ?> value="success">Success</option>
                                    <option <?php if(request('status')=='delivered'): ?> selected <?php endif; ?> value="success">Delivered</option>
                                    <option <?php if(request('status')=='reject'): ?> selected <?php endif; ?> value="reject">Reject</option>
                                </select>
                            </div>
                        </div>
                        <div class="row align-content-center mb-2">
                            <div class="col-4">From Date</div>
                            <div class="col">
                                <input type="date" value="<?php echo e(request('from_date')); ?>" name="from_date"  class="form-control">
                            </div>
                        </div>
                        <div class="row align-content-center mb-2">
                            <div class="col-4">To Date</div>
                            <div class="col">
                                <input type="date" value="<?php echo e(request('to_date')); ?>" name="to_date"  class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Filter</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            activeSidebar('.order_view');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\a to z\projects\shop_vue+laravel\api\resources\views/page/order/list.blade.php ENDPATH**/ ?>